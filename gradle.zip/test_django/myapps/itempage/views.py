# -*- coding: utf-8 -*-
from django.http import HttpResponse
from django.http import Http404
from django.shortcuts import get_object_or_404
from django.shortcuts import render
from django.template import Context, loader, RequestContext
from models import Item
from forms import ItemSearchForm
from cart import CartItem
from django.views.decorators.csrf import csrf_protect
#from django.views.generic.simple import direct_to_template


def item_page_display(request,item_id):
    
    u'''
    try:
        # item_idに該当するオブジェクトを取得する
        item = Item.objects.get(id=item_id)
    except Item.DoesNotExist:
        raise Http404
        pass
    '''
    
    item = get_object_or_404(Item, id=item_id)
    
    # テンプレートを取得して、モデルの値とマージする
    t = loader.get_template('page/item.html')
    c = Context(
        {'item':item }
    )
    # HTTP Responseを返す。
    return HttpResponse(t.render(c))

@csrf_protect
def item_search(request):

    if request.method == 'POST':
        form = ItemSearchForm(request.POST)
        if form.is_valid():
            items = Item.objects.filter(item_name=form.cleaned_data['item_name'])
            ctxt = RequestContext(request,
                                  {
                    'form': form,
                    'items': items,
                    })
            return render(request,'page/item_search.html',ctxt)
    else:
        #検索フォームの初期表示
        form = ItemSearchForm()

    ctxt = RequestContext(request,
                          {
                    'form': form,
                    'items': items,
            })
    return render(request,'page/item_search.html',cctxt)


def do_cart(request):

    # hiddenのitem_idを取得しintに型変換
    item_id = int(request.POST['item_id'])
    item = Item.objects.get(id=item_id)

    # DBからItem情報を取得する。
    cart_item_list = request.session.get('cart_item_list',[])
    ci = CartItem()
    ci.item_id = item_id
    ci.item_code = item.item_code
    ci.item_name = item.item_name
    ci.price = item.price
    ci.buy_num = request.POST['buy_num']
    cart_item_list.append(ci)
    request.session['cart_item_list'] = cart_item_list

    return render(request,'page/cart_item_list.html',
        {
            'cart_item_list': cart_item_list,
        }
    )
