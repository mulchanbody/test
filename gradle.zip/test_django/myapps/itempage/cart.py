# -*- coding: utf-8 -*-

class CartItem:
    item_id = 0
    item_code = None
    item_name = None
    price = 0
    buy_num =0
