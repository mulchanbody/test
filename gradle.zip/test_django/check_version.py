
import django
print django.VERSION


