
// comment

/*
  var:
  其のスコープにおける変数を定義する。
  
  var i = 0;
  var j = 0;
  var f = function()
  {
    var i = 3;
    j = 3;
  };
  
  //output
  //i = 0
  //j = 3
  
  python では逆にglobal variableに 子のスコープでglobalとつけ知らせる。
  
  
  glossary:
  {} -> object
  [] -> array
  
  function(){} -> function object
  
  var Object = {
    property:
  }:
  
  propertyは[""]でアクセス可能。
  var obj = new Object();
  obj.property;
  obj["property"];
  
  
  
  
  
  
  
  
  
  
  
  
 */

// define function object
//function print(aa)
var print = function(aa)
{
    console.log(aa);
};

    

// class
// constructor
var AFrame = function(w,h)
{
    this.w = w;
    this.h = h;
};

// define member function
AFrame.prototype = {
 show: function()
 {
     console.log("w,h = " + this.w + "," + this.h);
 },
 show_width: function()
 {
     console.log("w = " + this.w);
 } 
};

// add member method
AFrame.prototype.show2 = function()
{
    console.log("w,h = " + this.w + "," + this.h);
};


//----------------------------------------------
// inheritance 
/*
  TODO:
  * derivedでEnemyのconstructorを実行できてない。できても実行順序が違う。
 */

// base class
var Enemy = function(life)
{
    //console.log("Enemy(), life = ",life);
    this.data = 1;
    this.life = life;
};
Enemy.prototype = 
{
 draw: function()
 {
     this.do_draw();
 },
 // virtual function
 do_draw: function()
 {
     console.log("Enemy::draw(), data,life = ",this.data,this.life);
 }
 
};


// derived class

var StrongEnemy = function(life)
{
    Enemy.call(this,life)
    console.log("StrongEnemy()");
    this.data = 2;
    this.life = this.life * 10;
};
StrongEnemy.prototype = new Enemy();

// concrete function
StrongEnemy.prototype.do_draw = function()
{
    console.log("StrongEnemy::draw(), data,life = " + this.data + "," + this.life);
};


// derived class 2
/*
var BigEnemy = new Enemy();

// concrete function
BigEnemy.prototype.do_draw = function()
{
    console.log("BigEnemy::draw(), data = " + this.data);
};
*/


function polymo(a)
{
    console.log(a)
}

function polymo(a,b)
{
    console.log(a+","+b)
}


// namespace 

var nsdev  = {};

nsdev.math = {};

nsdev.math.Vector3 = function()
{
    this.x = 0
    this.y = 0
    this.z = 0
    
};

var plus = function(l,r)
{
    ret = new Vector3();
    ret.x = l.x + r.x;
    ret.y = l.y + r.y;
    ret.z = l.z + r.z;
    return ret;
};


// private variable and function




// variable argument
var average = function()
{
    var sum=0;
    
    for (i = 0; i < arguments.length; i++) {
	sum += arguments[i];
    }
    return sum / arguments.length;    
};


// lambda function


var test_lambda = {
 
 test_lambda: function()
 {
     (function(x){
	 
	 console.log(x);
     })("test_lambda");
     
     
 },
 
 test: function()
 {
     this.test_lambda();
     
     
 },
};


var test_array = 
{
    /*
      new Array(..) -> [..]
     */
 test_array: function()
 {
     //var ar = new Array(1,2,"aa");
     var ar = [1,2,"aa"];
     console.log(ar[0],ar[1],ar[2]);
     ar["name"] = "micheal";
     console.log(ar["name"]);
     
     for(i=0; i<ar.length; ++i) {
	 
	 console.log(ar[i]);
     };
     
 },

 /*
   連想配列はobject.
   new Object() -> {}
 */
 test_associated_array: function()
 {
     var homer =
     {
	 "name": "Homer Simpson",
	 "age" : 34,
     };
     
     console.log(homer.age,homer["age"]);
    
     for(var i in homer){
	 console.log(homer[i]); 
     };
     
     
 },
 
    
 test: function()
 {
     this.test_array();
     this.test_associated_array();
     
     
 },
    
};


/*
 */
var test_closure = {

 test_0: function()
 {
     var Counter = function(){
	 var x = 0;
     
	 /*
	   関数を返す。
	  */
	 return function(){
	     x = x + 1;
	     console.log(x);
	     //return x;
	 };
     };
     
     c1 = new Counter();
     c1();
     c1();
     c1();
 },


 test_1: function()
 {
     var Counter = function(){
	 var x = 0;
     
	 /*
	   return 必須
	  */
	 var inner = function(){

	     x = x + 1;
	     console.log(x);
	 };
	 console.log(x);	 
	 return inner;
     };
     
     c1 = new Counter();
     c1();
     c1();
     c1();
 },
 
 
 test: function()
 {
     //this.test_0();
     with(this)
     {
	 test_1();
     }
     
     
 },
};


//===================================================
// test functions

var test_class = function()
{
    f = new AFrame(100,100);
    f.show();
    f.show_width();
    f.show2();
};




/*
  
 */
var test_inheritance = function()
{
    enemy = new Enemy(1);
    enemy.draw();
    
    enemy = new StrongEnemy(1);
    enemy.draw();
    
    
    //enemy = new BigEnemy();
    //enemy.draw();
};

// unexpected behavior.
var test_polymophism = function()
{
    polymo(1);
    polymo(1,2);
    
};
   
var test_namespace = function()
{
    var a = new nsdev.math.Vector3()
    
    
    // using namespace 
    // withを使う。ただし非推奨
    
    // using 
    var Vector3 = nsdev.math.Vector3;
    var b = new Vector3();
    
    
    // namespace 
    nm = nsdev.math;
    var c = new nm.Vector3();    
};


var test_variable_argument = function()
{
    console.log("average = ",average(1,2,3,4,5));
};
    




