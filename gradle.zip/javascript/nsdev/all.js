

//document.write("a");
var write_include_file = function(file_name){
 
    var xx = "<script type='text/javascript' src='";
    loc = location.href + "/" + file_name + "'></script>";
    document.write(xx + loc);
};

write_include_file("base.js");
write_include_file("functions.js");


var test = function()
{
    console.log("includes::test()");
};