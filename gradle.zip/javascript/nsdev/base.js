

var nsdev = {};
